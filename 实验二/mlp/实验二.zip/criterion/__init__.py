# -*- encoding: utf-8 -*-
from criterion.softmax_cross_entropy import SoftmaxCrossEntropyLossLayer
from criterion.euclidean_loss import EuclideanLossLayer